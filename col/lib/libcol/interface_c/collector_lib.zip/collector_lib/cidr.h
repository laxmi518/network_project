#ifndef CIDR_H
#define CIDR_H

// #include "lplog.h"
// extern lplog_context_t *lplog_context_global;

char *get_config_ip(char *dev_ip, json_t *client_map);

#endif