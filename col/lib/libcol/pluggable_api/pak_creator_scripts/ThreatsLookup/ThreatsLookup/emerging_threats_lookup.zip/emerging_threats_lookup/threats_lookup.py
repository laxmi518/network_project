
import os
import urllib2
import logging as log

def get_threat_lookup_data(base_path, threat_config):
	"""
	"""
	response = {"success": True, "rows": []}

	try:
		response_data = urllib2.urlopen(threat_config["url"])
	except Exception, e:
		log.warn("Exception fetching data from url %s : %s" % (threat_config["url"], str(e)))
    	response_file = os.path.join(base_path, threat_config["file"])
    	if os.path.exists(response_file):
    		response_data = open(response_file)
    	else:
    		return {"success": False, "message": "File %s conatining lookup data not found" % threat_config["file"]}

	headers = threat_config["headers"]

	i = 0
	for line in response_data.readlines():
		if i == 0:
			i = 1
			if threat_config["header_in_url"]:
				continue

		line_info = line.split(",")
		if len(headers) == len(line_info):
			row = {}
			for index, value in enumerate(headers):
				data = line_info[index].strip()
				if data.isdigit():
					data = int(data)
				row[value.strip()] = data
			response["rows"].append(row)
		else:
			log.warn("Headers and data length are not equal; header=%s, data=%s" % (headers, line_info))
			break
	return response