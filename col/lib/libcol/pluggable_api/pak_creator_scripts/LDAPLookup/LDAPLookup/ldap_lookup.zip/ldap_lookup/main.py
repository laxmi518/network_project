import os
import json
import logging as log

from ldapfetcher import get_data
from pylib.lookup_populator import index_lookup_data

def get_config_content(config_path):
    """
    """
    config = []
    if os.path.exists(config_path):
        try:
            with open(config_path) as f:
                config = json.loads(f.read())
        except Exception, e:
            log.warn("Error reading config file, %s" % str(e))
    else:
        log.warn("Config.json file not found")
    return config

def main():
    """
    """
    current_dir = os.path.dirname(os.path.abspath( __file__ ))
    config_path = os.path.join(current_dir, "config.json")

    config = get_config_content(config_path)

    for ldap_config in config:
        table_name = ldap_config["table_name"]

        ldap_response = get_data(ldap_config["host"], ldap_config["port"], ldap_config["bind_dn"], ldap_config["bind_password"], ldap_config["search_filter"], ldap_config["retrieve_attributes"], ldap_config["root"], ldap_config["ssl_enabled"])
        if ldap_response["success"] and ldap_response["rows"]:
            res = index_lookup_data(ldap_response["rows"], table_name)
            if not res["success"]:
                log.warn(res["message"])
        else:
            log.warn(ldap_response["message"])

if __name__ == "__main__":
    main()
