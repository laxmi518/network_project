
import logging
import ldap

from pylib import ldap_connection

def get_data(host, port, bind_dn, bind_password, search_filter, retrieve_attributes, root, ssl_enabled):
    connection = ldap_connection.get_ldap_server_connection(host, port, bind_dn, bind_password, ssl_enabled)
    if connection['success']:
        try:
            result = ldap_connection.retrieve_from_database(connection['connection'], root, ldap_connection.TREE, None, search_filter)
            keys = ldap_connection.get_all_keys(result)
        except ldap.LDAPError, err:
            logging.warn(err)
            return {'success': False, 'message': str(err)}

        if not set(retrieve_attributes or []).issubset(keys):
            error_attrs = set(retrieve_attributes).difference(keys)
            return {'success': False, 'message': 'Error in Retrieve Attributes: (%r)' % ', '.join(each for each in error_attrs)}
        try:
            result = ldap_connection.retrieve_from_database(connection['connection'], root, ldap_connection.TREE, retrieve_attributes, search_filter)
            return {'success': True, 'rows': result}
        except ldap.LDAPError, err:
            return {'success': False, 'message': repr(err)}
    else:
        return {'success': False, 'message':connection['message']}
